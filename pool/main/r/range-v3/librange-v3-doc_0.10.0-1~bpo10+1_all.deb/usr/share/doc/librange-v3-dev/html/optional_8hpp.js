var optional_8hpp =
[
    [ "bad_optional_access", "structranges_1_1bad__optional__access.html", "structranges_1_1bad__optional__access" ],
    [ "nullopt_t", "structranges_1_1nullopt__t.html", "structranges_1_1nullopt__t" ],
    [ "tag", "structranges_1_1nullopt__t_1_1tag.html", null ],
    [ "optional", "structranges_1_1optional.html", "structranges_1_1optional" ],
    [ "optional", "structranges_1_1optional.html", "structranges_1_1optional" ],
    [ "make_optional", "optional_8hpp.html#af47cb8ec8ee371306e1a8f0ca2020f10", null ],
    [ "make_optional", "optional_8hpp.html#a8fa73e1944d3c706238d42921ae069ab", null ],
    [ "make_optional", "optional_8hpp.html#a95812125e7c705eff0145fd501e7aa4b", null ],
    [ "optional_should_convert", "optional_8hpp.html#a834fc3b66c181f4c6c30c82afc69d933", null ],
    [ "optional_should_convert_assign", "optional_8hpp.html#a10247d6a988acc5b18c35f6f8f9de608", null ]
];