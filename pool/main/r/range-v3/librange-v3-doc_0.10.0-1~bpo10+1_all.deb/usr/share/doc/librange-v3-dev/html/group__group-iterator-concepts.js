var group__group_iterator_concepts =
[
    [ "incrementable_traits< detail::projected_< I, Proj > >", "structranges_1_1incrementable__traits_3_01detail_1_1projected___3_01I_00_01Proj_01_4_01_4.html", null ],
    [ "sentinel_tag", "structranges_1_1sentinel__tag.html", null ],
    [ "sized_sentinel_tag", "structranges_1_1sized__sentinel__tag.html", null ]
];