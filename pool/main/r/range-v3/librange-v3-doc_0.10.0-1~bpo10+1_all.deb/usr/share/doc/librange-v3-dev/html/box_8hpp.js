var box_8hpp =
[
    [ "get", "box_8hpp.html#gaf1376555372c27565e222efb19b7e24a", null ],
    [ "get", "box_8hpp.html#ga89730a20fdb515cb96ee84f857becde2", null ],
    [ "get", "box_8hpp.html#ga117b51fd4a49520eeebed078f7b4e44a", null ],
    [ "get", "box_8hpp.html#gae0554be0c62af9021dbfca0c2690dc0a", null ],
    [ "get", "box_8hpp.html#gae1b247766f3408db7c0fcf134e086c90", null ],
    [ "get", "box_8hpp.html#ga4bd3e8977b75cdbbe85fcfbb3ea745ca", null ]
];