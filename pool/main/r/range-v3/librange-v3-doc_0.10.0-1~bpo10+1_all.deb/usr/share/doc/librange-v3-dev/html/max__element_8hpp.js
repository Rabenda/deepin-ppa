var max__element_8hpp =
[
    [ "max_element", "max__element_8hpp.html#gab9289134adb9df908a681c75fb60b0d7", null ],
    [ "max_element", "max__element_8hpp.html#ga4e5950e393a0aee33b00b34c2f8e97c9", null ]
];