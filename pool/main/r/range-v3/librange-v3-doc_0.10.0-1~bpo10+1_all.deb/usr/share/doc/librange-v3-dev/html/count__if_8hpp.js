var count__if_8hpp =
[
    [ "count_if", "count__if_8hpp.html#gaa6d7932d258fee27a78a08afefdeda1b", null ],
    [ "count_if", "count__if_8hpp.html#ga8a066f39ca76bf1389b93ffd55720f7e", null ]
];