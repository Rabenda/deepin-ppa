var partition__copy_8hpp =
[
    [ "partition_copy_result", "partition__copy_8hpp.html#ga196586ea2693c3b679d7c75c8c8c4eb2", null ],
    [ "partition_copy", "partition__copy_8hpp.html#ga185594ec5d6552ed26713d8080b5f453", null ],
    [ "partition_copy", "partition__copy_8hpp.html#ga4ab1056bfb465fe2475dee970b81c9b5", null ]
];