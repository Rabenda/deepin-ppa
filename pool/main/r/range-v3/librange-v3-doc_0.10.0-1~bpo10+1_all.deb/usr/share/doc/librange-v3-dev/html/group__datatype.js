var group__datatype =
[
    [ "list_like", "group__list.html", "group__list" ],
    [ "Integer sequence", "group__integral.html", "group__integral" ],
    [ "Extension", "group__extension.html", "group__extension" ],
    [ "lazy", "group__lazy__datatype.html", "group__lazy__datatype" ],
    [ "nil_", "structmeta_1_1nil__.html", null ],
    [ "inherit", "group__datatype.html#gae73103f7cd0758701d6f5fb9e4aebb8c", null ]
];