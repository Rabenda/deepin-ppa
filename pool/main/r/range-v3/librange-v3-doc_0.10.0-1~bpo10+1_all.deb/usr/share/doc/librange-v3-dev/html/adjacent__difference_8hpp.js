var adjacent__difference_8hpp =
[
    [ "adjacent_difference_result", "adjacent__difference_8hpp.html#ga2e5f71c9a38bdeeb5cba7ce22674f738", null ],
    [ "adjacent_difference", "adjacent__difference_8hpp.html#ga41dc0bfb58bbb4aadeeb806fe84d5dcc", null ],
    [ "differenceable", "adjacent__difference_8hpp.html#gade001c3f076e7b47b46524a96b26ac36", null ],
    [ "differenceable_", "adjacent__difference_8hpp.html#gaa6f9c103542e18c3d6e767200b5b0153", null ]
];