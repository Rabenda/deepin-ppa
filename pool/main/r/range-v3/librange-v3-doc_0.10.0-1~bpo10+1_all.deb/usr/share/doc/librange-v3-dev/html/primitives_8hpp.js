var primitives_8hpp =
[
    [ "cdata", "primitives_8hpp.html#ga1c3359d1155f499d6a766f0b31c76b06", null ],
    [ "data", "primitives_8hpp.html#a644336444254ea64ab0f5f10637c5648", null ],
    [ "disable_sized_range", "primitives_8hpp.html#a627e8fde4c275eab1373bd669a43325e", null ],
    [ "empty", "primitives_8hpp.html#gaa6d2e35ad946792475b84f985784e3e4", null ],
    [ "size", "primitives_8hpp.html#ga4e6d035b8bc656ea3435ccb106f4000b", null ]
];