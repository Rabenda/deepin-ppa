var group__invocation =
[
    [ "lazy", "group__lazy__invocation.html", "group__lazy__invocation" ],
    [ "defer", "structmeta_1_1defer.html", null ],
    [ "defer_i", "structmeta_1_1defer__i.html", null ],
    [ "id", "structmeta_1_1id.html", [
      [ "invoke", "structmeta_1_1id.html#a8a825485c343d310c2526c9e09fdfd7d", null ],
      [ "type", "structmeta_1_1id.html#a4744d0e07e65c7f7430a29828ea61f94", null ]
    ] ],
    [ "_t", "group__invocation.html#ga08e2193149605769f6052795ff0a87b1", null ],
    [ "apply", "group__invocation.html#ga2f71f17b6a6b48ea99134ddabd0e19a9", null ],
    [ "defer_trait", "group__invocation.html#ga5fef8be9ed0280ec1553a8f3cc5d85a1", null ],
    [ "defer_trait_i", "group__invocation.html#ga596c8fb8ea9eebc4892c682c14c0064f", null ],
    [ "invoke", "group__invocation.html#gac5c75197d5412d032f662b81e1a37e22", null ],
    [ "_v", "group__invocation.html#ga63ad9a7984ab9ece32f80a3d065d1729", null ]
];