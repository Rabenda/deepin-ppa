var algorithm_2generate__n_8hpp =
[
    [ "generate_n_result", "algorithm_2generate__n_8hpp.html#ga0cd85c482465e0fef02aec6733ec5e8a", null ],
    [ "generate_n", "algorithm_2generate__n_8hpp.html#ga742c959cbacfc3c1558285b96e9a5353", null ]
];