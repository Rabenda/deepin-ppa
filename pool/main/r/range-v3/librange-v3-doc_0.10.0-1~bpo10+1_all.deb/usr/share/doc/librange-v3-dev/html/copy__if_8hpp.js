var copy__if_8hpp =
[
    [ "copy_if_result", "copy__if_8hpp.html#ga5a179c5b7b8620b7fd95dc315cab0a39", null ],
    [ "copy_if", "copy__if_8hpp.html#ga9c7793e127e9f16451b8e2869ca8be78", null ],
    [ "copy_if", "copy__if_8hpp.html#gacf2c0297eeb25e9a6fd9d1323f4eb967", null ]
];