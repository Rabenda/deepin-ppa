var getlines_8hpp =
[
    [ "getlines", "getlines_8hpp.html#ga2ea182045e584ca4c06e8a904ccd2fae", null ]
];