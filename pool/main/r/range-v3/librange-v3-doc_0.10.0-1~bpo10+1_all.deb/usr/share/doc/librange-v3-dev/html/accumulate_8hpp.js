var accumulate_8hpp =
[
    [ "accumulate", "accumulate_8hpp.html#ga9ff37f2b8a2f10a8988efb7466f140c6", null ]
];