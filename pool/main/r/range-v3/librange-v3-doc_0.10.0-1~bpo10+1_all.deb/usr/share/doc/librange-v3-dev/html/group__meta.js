var group__meta =
[
    [ "Trait", "group__trait.html", "group__trait" ],
    [ "Logical", "group__logical.html", "group__logical" ],
    [ "Algorithms", "group__algorithm.html", "group__algorithm" ],
    [ "Datatype", "group__datatype.html", "group__datatype" ],
    [ "Math", "group__math.html", "group__math" ]
];