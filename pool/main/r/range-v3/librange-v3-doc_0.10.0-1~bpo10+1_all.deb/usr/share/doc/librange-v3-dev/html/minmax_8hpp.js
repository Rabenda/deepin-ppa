var minmax_8hpp =
[
    [ "minmax_result", "minmax_8hpp.html#ga33d3732bfda9763bacb492f678c49ac2", null ],
    [ "minmax", "minmax_8hpp.html#ga3e76c389abdd0a6fc082c8b8b19cf75a", null ],
    [ "minmax", "minmax_8hpp.html#ga0680914593784261a293977ba92fb994", null ],
    [ "minmax", "minmax_8hpp.html#ga7f84b92881ac8d36ec500601758b489e", null ]
];