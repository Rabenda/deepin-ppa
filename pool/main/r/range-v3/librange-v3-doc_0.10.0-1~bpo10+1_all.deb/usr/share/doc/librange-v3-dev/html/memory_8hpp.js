var memory_8hpp =
[
    [ "iter_ref", "memory_8hpp.html#gaa13f35c6d6371af2b1a1ed88f7cd8e5d", null ],
    [ "make_raw_buffer", "memory_8hpp.html#ga210213dccfbcc10d705e41e2031cadf6", null ]
];