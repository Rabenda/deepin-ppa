var group__group_numerics =
[
    [ "accumulate_fn", "structranges_1_1accumulate__fn.html", [
      [ "operator()", "structranges_1_1accumulate__fn.html#acddfa287aa06fc3a22043b380bf3764e", null ],
      [ "operator()", "structranges_1_1accumulate__fn.html#a5d6cfe5d21a25b42f365902cc7881a74", null ]
    ] ],
    [ "adjacent_difference_fn", "structranges_1_1adjacent__difference__fn.html", [
      [ "operator()", "structranges_1_1adjacent__difference__fn.html#a2055c9a8e257deb9d30e46c578f7b97b", null ],
      [ "operator()", "structranges_1_1adjacent__difference__fn.html#aa27cf29bf098ef5c5f86c84c72ba2ed4", null ],
      [ "operator()", "structranges_1_1adjacent__difference__fn.html#a9828d7a7a4031238b163b9d3c316d889", null ],
      [ "operator()", "structranges_1_1adjacent__difference__fn.html#abbb1faa1db33497b9cdb9d6009c046ed", null ]
    ] ],
    [ "inner_product_fn", "structranges_1_1inner__product__fn.html", [
      [ "operator()", "structranges_1_1inner__product__fn.html#aefe61ff242d5374fb232e12386711e8a", null ],
      [ "operator()", "structranges_1_1inner__product__fn.html#a282ae6d5f64c69ea4ad2913b17a77d9f", null ],
      [ "operator()", "structranges_1_1inner__product__fn.html#a9ca19417a2e260a03a6b36a63b4884eb", null ],
      [ "operator()", "structranges_1_1inner__product__fn.html#a86da72a893b61caec60d4fbb7538332e", null ]
    ] ],
    [ "iota_fn", "structranges_1_1iota__fn.html", [
      [ "operator()", "structranges_1_1iota__fn.html#a5bfe2b623527bc8ad4d3c14bd954644e", null ],
      [ "operator()", "structranges_1_1iota__fn.html#a7d9ee1d90de8ba588046f46af36f2ae8", null ]
    ] ],
    [ "partial_sum_fn", "structranges_1_1partial__sum__fn.html", [
      [ "operator()", "structranges_1_1partial__sum__fn.html#a500a5f923485c69dda9194b024ec5202", null ],
      [ "operator()", "structranges_1_1partial__sum__fn.html#afb1354c702540336059fc3c655e2f1c5", null ],
      [ "operator()", "structranges_1_1partial__sum__fn.html#ae1b83ba461dadde1fdd9b450029355b9", null ],
      [ "operator()", "structranges_1_1partial__sum__fn.html#a50665defe227955e144ca903139953a7", null ]
    ] ]
];