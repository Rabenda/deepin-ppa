var algorithm_2adjacent__remove__if_8hpp =
[
    [ "adjacent_remove_if", "algorithm_2adjacent__remove__if_8hpp.html#ga2d08c6a9c28092deaa0a55dfc92fd1cd", null ],
    [ "adjacent_remove_if", "algorithm_2adjacent__remove__if_8hpp.html#ga7eb3423653bb64e8fec6c9103d0b2fd9", null ]
];