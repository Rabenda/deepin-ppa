var NAVTREE =
[
  [ "Range-v3", "index.html", [
    [ "User Manual", "index.html", [
      [ "Preface", "index.html#tutorial-preface", [
        [ "Installation", "index.html#tutorial-installation", null ],
        [ "License", "index.html#tutorial-license", null ],
        [ "Supported Compilers", "index.html#tutorial-compilers", null ]
      ] ],
      [ "Quick Start", "index.html#tutorial-quick-start", [
        [ "Views", "index.html#tutorial-views", null ],
        [ "Actions", "index.html#tutorial-actions", null ],
        [ "Utilities", "index.html#tutorial-utilities", null ],
        [ "Concept Checking", "index.html#tutorial-concepts", null ],
        [ "Range-v3 and the Future", "index.html#tutorial-future", null ]
      ] ]
    ] ],
    [ "Examples", "md_examples.html", [
      [ "Examples: Algorithms", "md_examples.html#example-algorithms", [
        [ "Hello, Ranges!", "md_examples.html#example-hello", null ],
        [ "any_of, all_of, none_of", "md_examples.html#example-any-all-none", null ],
        [ "count", "md_examples.html#example-count", null ],
        [ "count_if", "md_examples.html#example-count_if", null ],
        [ "find, find_if, find_if_not on sequence containers", "md_examples.html#example-find", null ],
        [ "for_each on sequence containers", "md_examples.html#example-for_each-seq", null ],
        [ "for_each on associative containers", "md_examples.html#example-for_each-assoc", null ],
        [ "is_sorted", "md_examples.html#example-is_sorted", null ]
      ] ],
      [ "Examples: Views", "md_examples.html#example-views", [
        [ "Filter and transform", "md_examples.html#example-filter-transform", null ],
        [ "Generate ints and accumulate", "md_examples.html#example-accumulate-ints", null ],
        [ "Convert a range comprehension to a vector", "md_examples.html#example-comprehension-conversion", null ]
      ] ],
      [ "Examples: Actions", "md_examples.html#example-actions", [
        [ "Remove non-unique elements from a container", "md_examples.html#example-sort-unique", null ]
      ] ],
      [ "Examples: Putting it all together", "md_examples.html#example-gestalt", [
        [ "Calendar", "md_examples.html#example-calendar", null ]
      ] ]
    ] ],
    [ "Release Notes", "release_notes.html", [
      [ "Version 0.10.0 \"To Err is Human\"", "release_notes.html#v0-10-0", null ],
      [ "Version 0.9.1", "release_notes.html#v0-9-1", null ],
      [ "Version 0.9.0 \"Std::ranger Things\"", "release_notes.html#v0-9-0", null ],
      [ "Version 0.5.0", "release_notes.html#v0-5-0", null ],
      [ "Version 0.4.0", "release_notes.html#v0-4-0", null ],
      [ "Version 0.3.7", "release_notes.html#v0-3-7", null ],
      [ "Version 0.3.6", "release_notes.html#v0-3-6", null ],
      [ "Version 0.3.5", "release_notes.html#v0-3-5", null ],
      [ "Version 0.3.0", "release_notes.html#v0-3-0", null ],
      [ "Version 0.2.6", "release_notes.html#v0-2-6", null ],
      [ "Version 0.2.5", "release_notes.html#v0-2-5", null ],
      [ "Version 0.2.4", "release_notes.html#v0-2-4", null ],
      [ "Version 0.2.3", "release_notes.html#v0-2-3", null ],
      [ "Version 0.2.2", "release_notes.html#v0-2-2", null ],
      [ "Version 0.2.1", "release_notes.html#v0-2-1", null ],
      [ "Version 0.2.0", "release_notes.html#v0-2-0", null ],
      [ "Version 0.1.1", "release_notes.html#v0-1-1", null ],
      [ "Version 0.1.0", "release_notes.html#v0-1-0", null ]
    ] ],
    [ "Reference", "modules.html", "modules" ],
    [ "Indexes", "usergroup0.html", [
      [ "Methods", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ],
      [ "Classes", "annotated.html", "annotated" ],
      [ "Files", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"classtuple__element.html",
"concepts_2swap_8hpp.html#a3b6076dd558ba67eb965f316e4570d43",
"group__group-algorithms.html#ga4cb85c9a5ce8c5773f1f7f8fa9d6ef15",
"group__group-views.html#ga4704aba65a79bda66657f80b6ac1217e",
"group__query.html#gaf33139f1b442de0272477e126d6d66a7",
"meta_8hpp.html#ga5738a7d892d9bf6f281f87b556057ecb",
"permutation_8hpp.html#gab0cb1e10c1bb0af166f8fcbe632b6970",
"semiregular__box_8hpp.html",
"structranges_1_1any.html#a657c6de748c5b513c19c85c907b1d36e",
"structranges_1_1drop__last__view_3_01Rng_00_01detail_1_1drop__last__view_1_1mode__bidi_01_4.html#a23d46a54441352f014d9b4c154cb3e81",
"structranges_1_1make__action__closure__fn.html",
"structranges_1_1remove__if__view.html#ad45afa95ffa603fd0dfd9c1816dabd60",
"structranges_1_1view__interface.html#aa93d76ec2d7a6e61090dc227b9d4eead",
"structranges_1_1views_1_1take__last__base__fn.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';