var interface_8hpp =
[
    [ "CPP_template_gcc_workaround", "interface_8hpp.html#ade48b10120b391e12f85030c8cc3111a", null ],
    [ "view_interface", "interface_8hpp.html#a5b9be72ba016481038206c255b2c45dc", null ]
];