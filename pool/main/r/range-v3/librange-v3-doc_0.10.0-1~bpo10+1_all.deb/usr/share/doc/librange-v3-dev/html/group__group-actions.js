var group__group_actions =
[
    [ "make_action_closure_fn", "structranges_1_1make__action__closure__fn.html", [
      [ "operator()", "structranges_1_1make__action__closure__fn.html#a7ea394935f617fa034f12b2821dcf7bf", null ]
    ] ],
    [ "push_back_fn", "structranges_1_1push__back__fn.html", [
      [ "operator()", "group__group-actions.html#gad1a748ebedebb325965b7b62374b1219", null ],
      [ "operator()", "group__group-actions.html#ga1fd3e7259750816a42ee321f07ebeb3c", null ],
      [ "operator()", "group__group-actions.html#ga1d26d7a23894e984c70c86b57ffef4b4", null ],
      [ "operator()", "group__group-actions.html#ga876f4d48dea13ac6165771f7903d2a36", null ],
      [ "operator()", "group__group-actions.html#gaaba9729de37be56215fc35a8dbd96536", null ]
    ] ],
    [ "make_action_closure", "group__group-actions.html#gaeb264d48f731e75689136caf2f888e13", null ]
];