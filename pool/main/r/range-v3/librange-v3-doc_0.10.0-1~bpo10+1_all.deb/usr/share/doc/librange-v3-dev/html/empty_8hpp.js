var empty_8hpp =
[
    [ "empty_view", "empty_8hpp.html#accc939ed906402869056576f5459eeeb", null ],
    [ "empty", "empty_8hpp.html#ab84e05114c699c99bb506f5406d60622", null ],
    [ "enable_safe_range< empty_view< T > >", "empty_8hpp.html#ga69a5db2eeb75a75c2483e9f2f5193281", null ]
];