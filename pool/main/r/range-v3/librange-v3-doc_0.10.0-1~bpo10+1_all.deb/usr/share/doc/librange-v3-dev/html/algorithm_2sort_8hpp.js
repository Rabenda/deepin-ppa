var algorithm_2sort_8hpp =
[
    [ "sort", "algorithm_2sort_8hpp.html#ga378358ecf6ab51d495d97b9eccdb2b95", null ],
    [ "sort", "algorithm_2sort_8hpp.html#ga0fda77d6d9ad1a234b712d92c949ea37", null ]
];