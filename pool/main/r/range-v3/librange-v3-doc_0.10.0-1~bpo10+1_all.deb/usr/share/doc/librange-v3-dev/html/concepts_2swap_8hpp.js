var concepts_2swap_8hpp =
[
    [ "CPP_CXX14_CONSTEXPR", "concepts_2swap_8hpp.html#ad1edf6743264394c58a3f700833fbefd", null ],
    [ "CPP_CXX_INLINE_VARIABLES", "concepts_2swap_8hpp.html#a8f0ea9b7550a082282d5b1aeda5ace37", null ],
    [ "CPP_DEFINE_CPO", "concepts_2swap_8hpp.html#aef20716bdef4ec4ef186163e4802a707", null ],
    [ "CPP_DIAGNOSTIC_IGNORE_CPP2A_COMPAT", "concepts_2swap_8hpp.html#a40294a919c0317762b5e090e2de854ec", null ],
    [ "CPP_DIAGNOSTIC_IGNORE_FLOAT_EQUAL", "concepts_2swap_8hpp.html#a41f40e094ef97146a251d098b182a612", null ],
    [ "CPP_DIAGNOSTIC_IGNORE_INIT_LIST_LIFETIME", "concepts_2swap_8hpp.html#a3b6076dd558ba67eb965f316e4570d43", null ],
    [ "CPP_DIAGNOSTIC_POP", "concepts_2swap_8hpp.html#a7eff43fb5007bd3b02a45328aa5a6fa2", null ],
    [ "CPP_DIAGNOSTIC_PUSH", "concepts_2swap_8hpp.html#a94504c6278c1142eb82374bc06102846", null ],
    [ "CPP_INLINE_VAR", "concepts_2swap_8hpp.html#a63d78fd114a84820a67528b7595b5b8b", null ],
    [ "CPP_INLINE_VARIABLE", "concepts_2swap_8hpp.html#a89b726f476c46708cf7b51fb906392fe", null ],
    [ "exchange", "concepts_2swap_8hpp.html#ab624c63181c7115e1ac085d186fbced2", null ]
];