var minmax__element_8hpp =
[
    [ "minmax_element_result", "minmax__element_8hpp.html#ga2551631b044f18c25ebf252d89ab62d1", null ],
    [ "minmax_element", "minmax__element_8hpp.html#ga941f844d9a850179cb16a4ccc5b9b071", null ],
    [ "minmax_element", "minmax__element_8hpp.html#gae13f61b4b199b34e72551c035de4a491", null ]
];