var in__place_8hpp =
[
    [ "in_place", "in__place_8hpp.html#abc127251cc80d4535bb6e28f60beb24d", null ]
];