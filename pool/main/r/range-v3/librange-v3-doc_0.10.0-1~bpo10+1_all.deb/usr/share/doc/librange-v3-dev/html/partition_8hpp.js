var partition_8hpp =
[
    [ "partition", "partition_8hpp.html#ga44ec603253c1d8b7db74726ff72fcab7", null ],
    [ "partition", "partition_8hpp.html#gabe6a0c55a56570b91f62b59f9dc906c7", null ]
];