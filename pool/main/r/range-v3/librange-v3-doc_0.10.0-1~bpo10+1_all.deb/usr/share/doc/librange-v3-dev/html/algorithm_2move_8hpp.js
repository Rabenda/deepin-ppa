var algorithm_2move_8hpp =
[
    [ "move_result", "algorithm_2move_8hpp.html#gaa9e56e40c245536a73cd3c4479aa71f0", null ],
    [ "move", "algorithm_2move_8hpp.html#ga51a5571f63c297cfd285f4a3873737dc", null ],
    [ "move", "algorithm_2move_8hpp.html#gaa55485146994b298d1392f1aa421fdfe", null ]
];