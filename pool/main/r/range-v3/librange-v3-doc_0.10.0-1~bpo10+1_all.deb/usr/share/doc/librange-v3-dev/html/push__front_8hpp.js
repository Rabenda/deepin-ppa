var push__front_8hpp =
[
    [ "push_front", "push__front_8hpp.html#ab2a99229d6d26f0845e7450e53cc54d2", null ]
];